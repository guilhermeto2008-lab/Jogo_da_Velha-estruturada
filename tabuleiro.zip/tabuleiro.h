#ifndef TABULEIRO_H
#define TABULEIRO_H

#define VAZIO      0
#define JOGADOR_O  1
#define JOGADOR_X  4

typedef struct{
    int M[3][3];
}Tabuleiro;

void inicializaTabuleiro (Tabuleiro *t);
void desenha(Tabuleiro *t);
void marcaJogada(Tabuleiro *t, int linha, int coluna, int tipo);
void temVencedor(Tabuleiro *t);

#endif

